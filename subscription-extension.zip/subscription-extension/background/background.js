async function getNotificationSettings() {
    const result = await chrome.storage.local.get(['notificationSettings']);
    return result.notificationSettings || { notify3days: true, notify1day: true };
}

function formatPriceForNotification(price, currency) {
    const symbols = { RUB: "₽", USD: "$", EUR: "€", GBP: "£", KZT: "₸" };
    const symbol = symbols[currency] || currency;
    if (currency === 'USD' || currency === 'EUR' || currency === 'GBP') {
        return price.toFixed(2) + symbol;
    }
    return Math.round(price) + symbol;
}

async function checkUpcomingPayments() {
    try {
        const result = await chrome.storage.local.get(['subscriptions']);
        const subscriptions = result.subscriptions || [];
        const settings = await getNotificationSettings();
        
        if (subscriptions.length === 0) {
            console.log('📭 Нет активных подписок');
            return;
        }
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        for (const sub of subscriptions) {
            if (!sub.nextPayment) continue;
            
            const paymentDate = new Date(sub.nextPayment);
            paymentDate.setHours(0, 0, 0, 0);
            const daysUntil = Math.ceil((paymentDate - today) / (1000 * 60 * 60 * 24));
            
            let shouldNotify = false;
            let message = '';
            let priority = 1;
            
            if (daysUntil === 3 && settings.notify3days) {
                shouldNotify = true;
                message = `📅 Через 3 дня спишется ${formatPriceForNotification(sub.price, sub.currency || 'RUB')} за ${sub.name}`;
            } else if (daysUntil === 1 && settings.notify1day) {
                shouldNotify = true;
                message = `⚠️ ЗАВТРА спишется ${formatPriceForNotification(sub.price, sub.currency || 'RUB')} за ${sub.name}`;
                priority = 2;
            } else if (daysUntil === 0) {
                shouldNotify = true;
                message = `🔔 СЕГОДНЯ спишется ${formatPriceForNotification(sub.price, sub.currency || 'RUB')} за ${sub.name}`;
                priority = 2;
            }
            
            if (shouldNotify) {
                const notificationKey = `notified_${sub.id}_${daysUntil}`;
                const lastNotified = await chrome.storage.local.get([notificationKey]);
                const todayStr = today.toISOString().split('T')[0];
                
                if (lastNotified[notificationKey] !== todayStr) {
                    try {
                        await chrome.notifications.create({
                            type: 'basic',
                            iconUrl: '/icons/2.png',
                            title: 'Менеджер Подписок',
                            message: message,
                            priority: priority,
                            silent: false,
                            requireInteraction: daysUntil === 0
                        });
                        
                        await chrome.storage.local.set({ [notificationKey]: todayStr });
                        console.log(`✅ Уведомление отправлено: ${sub.name}`);
                    } catch (notifError) {
                        console.error('Ошибка уведомления:', notifError);
                    }
                }
            }
        }
    } catch (error) {
        console.error('Ошибка проверки подписок:', error);
    }
}

async function updateBadge() {
    try {
        const result = await chrome.storage.local.get(['subscriptions']);
        const subscriptions = result.subscriptions || [];
        const total = subscriptions.reduce((sum, sub) => sum + (sub.price || 0), 0);
        
        if (total > 0) {
            await chrome.action.setBadgeText({ text: Math.round(total).toString() });
            await chrome.action.setBadgeBackgroundColor({ color: '#ff4757' });
        } else {
            await chrome.action.setBadgeText({ text: '' });
        }
    } catch (error) {
        console.error('Ошибка обновления бейджа:', error);
    }
}

async function setupAlarm() {
    try {
        await chrome.alarms.clear('checkPayments');
        await chrome.alarms.create('checkPayments', {
            periodInMinutes: 720,
            delayInMinutes: 1
        });
        console.log('✅ Alarm создан');
    } catch (error) {
        console.error('Ошибка создания alarm:', error);
    }
}

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'checkPayments') {
        console.log('🕐 Проверка подписок:', new Date().toLocaleString());
        checkUpcomingPayments();
    }
});

chrome.storage.onChanged.addListener((changes) => {
    if (changes.subscriptions) {
        updateBadge();
        checkUpcomingPayments();
    }
});

chrome.notifications.onClicked.addListener(() => {
    console.log('🔔 Клик по уведомлению');
    try {
        chrome.action.openPopup().catch(() => {});
    } catch (e) {}
});

async function init() {
    console.log('🚀 Менеджер Подписок запущен');
    

    try {
        const allData = await chrome.storage.local.get(null);
        const now = new Date();
        let cleaned = 0;
        
        for (const key in allData) {
            if (key.startsWith('notified_')) {
                const dateStr = allData[key];
                if (dateStr) {
                    const notifiedDate = new Date(dateStr);
                    const daysDiff = (now - notifiedDate) / (1000 * 60 * 60 * 24);
                    if (daysDiff > 7) {
                        await chrome.storage.local.remove(key);
                        cleaned++;
                    }
                }
            }
        }
        if (cleaned > 0) console.log(`🧹 Очищено ${cleaned} записей`);
    } catch (e) {}
    
    await updateBadge();
    await setupAlarm();
    await checkUpcomingPayments();
    console.log('✅ Инициализация завершена');
}

init();