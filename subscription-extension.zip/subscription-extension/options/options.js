document.addEventListener('DOMContentLoaded', () => {
    const exportBtn = document.getElementById('export-btn');
    const importBtn = document.getElementById('import-btn');
    const clearDataBtn = document.getElementById('clear-data-btn');
    const notify3days = document.getElementById('notify-3days');
    const notify1day = document.getElementById('notify-1day');
    const baseCurrencySelect = document.getElementById('base-currency');


    function loadSettings() {
        chrome.storage.local.get(['notificationSettings', 'baseCurrency'], (result) => {
            if (result.notificationSettings) {
                if (notify3days) notify3days.checked = result.notificationSettings.notify3days !== false;
                if (notify1day) notify1day.checked = result.notificationSettings.notify1day !== false;
            }
            if (baseCurrencySelect && result.baseCurrency) {
                baseCurrencySelect.value = result.baseCurrency;
            }
        });
    }


    function saveNotificationSettings() {
        const settings = {
            notify3days: notify3days ? notify3days.checked : true,
            notify1day: notify1day ? notify1day.checked : true
        };
        chrome.storage.local.set({ notificationSettings: settings });
    }


    function saveBaseCurrency() {
        if (baseCurrencySelect) {
            chrome.storage.local.set({ baseCurrency: baseCurrencySelect.value });
        }
    }

    if (notify3days) notify3days.addEventListener('change', saveNotificationSettings);
    if (notify1day) notify1day.addEventListener('change', saveNotificationSettings);
    if (baseCurrencySelect) baseCurrencySelect.addEventListener('change', saveBaseCurrency);


    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            chrome.storage.local.get(['subscriptions'], (result) => {
                const subscriptions = result.subscriptions || [];
                if (subscriptions.length === 0) {
                    alert('📭 Нет подписок для экспорта!');
                    return;
                }

                const dataStr = JSON.stringify(subscriptions, null, 2);
                const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
                
                const link = document.createElement('a');
                link.href = dataUri;
                link.download = `subscriptions_${new Date().toISOString().split('T')[0]}.json`;
                link.click();
                
                alert(`✅ Экспортировано ${subscriptions.length} подписок!`);
            });
        });
    }


    if (importBtn) {
        importBtn.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'application/json';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                const reader = new FileReader();
                reader.onload = (event) => {
                    try {
                        const imported = JSON.parse(event.target.result);
                        if (!Array.isArray(imported)) {
                            throw new Error('Неверный формат');
                        }

                        // Улучшенная валидация импорта
                        const validSubscriptions = imported.filter(sub => {
                            return sub &&
                                   typeof sub.name === 'string' &&
                                   sub.name.trim().length > 0 &&
                                   typeof sub.price === 'number' &&
                                   sub.price > 0 &&
                                   typeof sub.nextPayment === 'string' &&
                                   !isNaN(Date.parse(sub.nextPayment));
                        });
                        
                        chrome.storage.local.get(['subscriptions'], (result) => {
                            const current = result.subscriptions || [];
                            const merged = [...current, ...validSubscriptions];
                            

                            const unique = merged.filter((sub, index, self) => 
                                index === self.findIndex(s => s.id === sub.id)
                            );
                            
                            chrome.storage.local.set({ subscriptions: unique }, () => {
                                const importedCount = validSubscriptions.length;
                                alert(`✅ Импортировано ${importedCount} валидных подписок! Всего: ${unique.length}`);
                            });
                        });
                    } catch (error) {
                        alert('❌ Ошибка при импорте: неверный формат файла');
                    }
                };
                reader.readAsText(file);
            };
            input.click();
        });
    }


    if (clearDataBtn) {
        clearDataBtn.addEventListener('click', () => {
            if (confirm('⚠️ Вы уверены, что хотите удалить ВСЕ подписки? Это действие нельзя отменить!')) {
                chrome.storage.local.set({ subscriptions: [] }, () => {
                    alert('🗑️ Все подписки удалены');
                });
            }
        });
    }

    loadSettings();
});