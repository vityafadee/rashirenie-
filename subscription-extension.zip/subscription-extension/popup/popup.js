document.addEventListener('DOMContentLoaded', () => {

    const listContainer = document.getElementById('subscriptions-list');
    const addBtn = document.getElementById('add-btn');
    const modal = document.getElementById('modal');
    const modalSave = document.getElementById('modal-save');
    const modalCancel = document.getElementById('modal-cancel');
    const themeBtn = document.getElementById('theme-btn');

    let subscriptions = [];

    function generateId() {
        return Date.now() + Math.random();
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#x27;');
    }

    // Защита от вредоносных цветов
    function sanitizeColor(color) {
        if (!color) return '#4a6bff';
        const valid = /^#([0-9a-fA-F]{3,6})$/.test(color);
        return valid ? color : '#4a6bff';
    }

    function getServiceColor(name) {
        if (window.popularServices) {
            const service = window.popularServices.find(s => s.name.toLowerCase() === name.toLowerCase());
            if (service) return service.color;
        }
        const colors = ['#4a6bff', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    function getServiceIcon(name) {
        if (window.popularServices) {
            const service = window.popularServices.find(s => s.name.toLowerCase() === name.toLowerCase());
            if (service && service.icon) return service.icon;
        }
        return '📦';
    }

    function getCurrencySymbol(currency) {
        return window.currencySymbols?.[currency] || currency;
    }

    function formatPrice(price, currency) {
        const symbol = getCurrencySymbol(currency);
        if (currency === 'USD' || currency === 'EUR' || currency === 'GBP') {
            return price.toFixed(2) + ' ' + symbol;
        }
        return Math.round(price) + ' ' + symbol;
    }

    async function calculateTotalInRUB() {
        const rates = window.exchangeRates || { RUB: 1, USD: 70, EUR: 82, GBP: 95, KZT: 0.15 };
        return subscriptions.reduce((sum, sub) => {
            const currency = sub.currency || 'RUB';
            const rate = rates[currency] || 1;
            return sum + (sub.price * rate);
        }, 0);
    }

    async function renderSubscriptions() {
        const totalRub = await calculateTotalInRUB();
        const totalAmount = document.getElementById('total-amount');
        if (totalAmount) {
            totalAmount.textContent = Math.round(totalRub) + ' ₽';
        }

        listContainer.innerHTML = '';

        if (subscriptions.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'empty-state';
            empty.innerHTML = 'Нет активных подписок<br>Нажмите "+" чтобы добавить';
            listContainer.appendChild(empty);
            return;
        }

        const sorted = [...subscriptions].sort((a, b) => new Date(a.nextPayment) - new Date(b.nextPayment));

        sorted.forEach(sub => {
            const item = document.createElement('div');
            item.className = 'subscription-item';
            const safeColor = sanitizeColor(sub.color || getServiceColor(sub.name));
            item.style.borderLeftColor = safeColor;

            const icon = getServiceIcon(sub.name);
            const formattedPrice = formatPrice(sub.price, sub.currency || 'RUB');

            item.innerHTML = `
                <div class="sub-info">
                    <div class="sub-name" style="color: ${safeColor}">
                        ${icon} ${escapeHtml(sub.name)}
                    </div>
                    <div class="sub-price">${escapeHtml(formattedPrice)}/мес</div>
                    <div class="sub-date">До ${escapeHtml(sub.nextPayment)}</div>
                </div>
                <button class="delete-btn" data-id="${escapeHtml(String(sub.id))}">✕</button>
            `;
            listContainer.appendChild(item);
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (confirm('Удалить эту подписку?')) {
                    const id = btn.dataset.id;
                    subscriptions = subscriptions.filter(s => s.id != id);
                    saveSubscriptions();
                    renderSubscriptions();
                }
            });
        });
    }

    function saveSubscriptions() {
        chrome.storage.local.set({ subscriptions: subscriptions });
    }

    function loadSubscriptions() {
        chrome.storage.local.get(['subscriptions'], (result) => {
            subscriptions = result.subscriptions || [];
            renderSubscriptions();
        });
    }

    function fillServiceData(serviceName) {
        const service = window.popularServices?.find(s => s.name === serviceName);
        if (service) {
            const priceInput = document.getElementById('modal-price');
            const currencySelect = document.getElementById('modal-currency');
            
            if (service.defaultPrice && (!priceInput.value || priceInput.value === '0')) {
                priceInput.value = service.defaultPrice;
            }
            if (service.currency && currencySelect) {
                currencySelect.value = service.currency;
            }
        }
    }

    function initCustomDropdown() {
        const nameInput = document.getElementById('modal-name');
        const dropdown = document.getElementById('service-dropdown');
        const serviceListDiv = document.getElementById('service-list');
        const searchInput = document.getElementById('service-search');
        
        if (!nameInput || !dropdown) return;
        
        function renderServiceList(services) {
            if (!serviceListDiv) return;
            serviceListDiv.innerHTML = '';
            
            if (!services || services.length === 0) {
                serviceListDiv.innerHTML = '<div class="service-option" style="justify-content:center; color:#999;">Ничего не найдено</div>';
                return;
            }
            
            services.forEach(service => {
                const option = document.createElement('div');
                option.className = 'service-option';
                option.innerHTML = `
                    <span class="service-option-icon">${service.icon || '📦'}</span>
                    <span class="service-option-name">${escapeHtml(service.name)}</span>
                `;
                option.addEventListener('click', (e) => {
                    e.stopPropagation();
                    nameInput.value = service.name;
                    dropdown.style.display = 'none';
                    fillServiceData(service.name);
                    document.getElementById('modal-price').focus();
                });
                serviceListDiv.appendChild(option);
            });
        }
        
        nameInput.addEventListener('focus', () => {
            renderServiceList(window.popularServices || []);
            dropdown.style.display = 'block';
        });
        
        nameInput.addEventListener('click', (e) => {
            e.stopPropagation();
            if (dropdown.style.display !== 'block') {
                renderServiceList(window.popularServices || []);
                dropdown.style.display = 'block';
            }
        });
        
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                e.stopPropagation();
                const query = e.target.value.toLowerCase();
                const filtered = (window.popularServices || []).filter(s => 
                    s.name.toLowerCase().includes(query)
                );
                renderServiceList(filtered);
            });
            
            searchInput.addEventListener('click', (e) => e.stopPropagation());
        }
        
        document.addEventListener('click', (e) => {
            if (nameInput && dropdown && !nameInput.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });
        
        if (dropdown) {
            dropdown.addEventListener('click', (e) => e.stopPropagation());
        }
    }

    function openModal() {
        modal.classList.add('show');
        setTimeout(() => {
            const nameInput = document.getElementById('modal-name');
            if (nameInput) {
                nameInput.focus();
                const dropdown = document.getElementById('service-dropdown');
                if (dropdown && window.popularServices) {
                    dropdown.style.display = 'block';
                }
            }
        }, 100);
    }

    function closeModal() {
        modal.classList.remove('show');
        document.getElementById('modal-name').value = '';
        document.getElementById('modal-price').value = '';
        document.getElementById('modal-date').value = '';
        document.getElementById('modal-currency').value = 'RUB';
        const dropdown = document.getElementById('service-dropdown');
        if (dropdown) dropdown.style.display = 'none';
    }

    function saveNewSubscription() {
        const name = document.getElementById('modal-name').value.trim();
        const price = parseFloat(document.getElementById('modal-price').value);
        const currency = document.getElementById('modal-currency').value;
        const nextPayment = document.getElementById('modal-date').value;

        if (!name) {
            alert('Введите название сервиса');
            document.getElementById('modal-name').focus();
            return;
        }

        if (isNaN(price) || price <= 0) {
            alert('Введите корректную стоимость (больше 0)');
            document.getElementById('modal-price').focus();
            return;
        }

        if (!nextPayment) {
            alert('Выберите дату следующего платежа');
            document.getElementById('modal-date').focus();
            return;
        }

        const newSubscription = {
            id: generateId(),
            name: name,
            price: price,
            currency: currency,
            nextPayment: nextPayment,
            color: getServiceColor(name),
            createdAt: new Date().toISOString()
        };

        subscriptions.push(newSubscription);
        saveSubscriptions();
        renderSubscriptions();
        closeModal();
    }

    function toggleTheme() {
        document.body.classList.toggle('dark');
        const isDark = document.body.classList.contains('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        themeBtn.textContent = isDark ? '☀️' : '🌙';
    }

    addBtn.addEventListener('click', openModal);
    modalCancel.addEventListener('click', closeModal);
    modalSave.addEventListener('click', saveNewSubscription);

    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    const settingsBtn = document.getElementById('settings-btn');
    if (settingsBtn) {
        settingsBtn.addEventListener('click', () => {
            if (chrome.runtime.openOptionsPage) {
                chrome.runtime.openOptionsPage();
            } else {
                window.open(chrome.runtime.getURL('options/options.html'));
            }
        });
    }

    if (themeBtn) {
        themeBtn.addEventListener('click', toggleTheme);
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark');
            themeBtn.textContent = '☀️';
        }
    }

    initCustomDropdown();
    loadSubscriptions();
});