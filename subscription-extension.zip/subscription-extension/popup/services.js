const popularServices = [

    { name: "Яндекс Музыка",           color: "#FF0000", icon: "🎵", currency: "RUB" },
    { name: "Яндекс Плюс",              color: "#FF0000", icon: "🌟", currency: "RUB" },
    { name: "VK Музыка",                color: "#5181B8", icon: "🎵", currency: "RUB" },
    { name: "VK Combo",                 color: "#5181B8", icon: "💙", currency: "RUB" },
    { name: "Звук",                     color: "#FF5E00", icon: "🎵", currency: "RUB" },
    { name: "МТС Music",                color: "#E30613", icon: "🎵", currency: "RUB" },
    

    { name: "Кинопоиск",                color: "#FF6600", icon: "🎥", currency: "RUB" },
    { name: "IVI",                      color: "#FF5E00", icon: "🍿", currency: "RUB" },
    { name: "Okko",                     color: "#FF6B35", icon: "🎬", currency: "RUB" },
    { name: "Premier",                  color: "#FF1493", icon: "💗", currency: "RUB" },
    { name: "Wink",                     color: "#FFD700", icon: "🌟", currency: "RUB" },
    { name: "START",                    color: "#00BFFF", icon: "▶️", currency: "RUB" },
    { name: "Amediateka",               color: "#8B4513", icon: "🎬", currency: "RUB" },
    { name: "More.tv",                  color: "#6A0DAD", icon: "📺", currency: "RUB" },
    { name: "Kion",                     color: "#00CED1", icon: "🎥", currency: "RUB" },
    { name: "Луч",                      color: "#FFD700", icon: "✨", currency: "RUB" },
    

    { name: "МТС Premium",              color: "#E30613", icon: "📱", currency: "RUB" },
    { name: "МегаФон",                  color: "#00A550", icon: "📱", currency: "RUB" },
    { name: "Билайн",                   color: "#FFD700", icon: "🐝", currency: "RUB" },
    { name: "Tele2",                    color: "#1E90FF", icon: "📱", currency: "RUB" },
    { name: "Yota",                     color: "#00BFFF", icon: "📱", currency: "RUB" },
    { name: "Тинькофф Мобайл",          color: "#FFD700", icon: "💳", currency: "RUB" },
    

    { name: "СберПрайм",                color: "#21A038", icon: "💚", currency: "RUB" },
    { name: "Тинькофф Pro",             color: "#FFD700", icon: "💳", currency: "RUB" },
    { name: "Альфа-Банк Плюс",          color: "#EF3124", icon: "🔴", currency: "RUB" },
    { name: "ВТБ Premium",              color: "#0A5C8E", icon: "🏦", currency: "RUB" },
    { name: "Газпромбанк Премиум",      color: "#005EB8", icon: "🏦", currency: "RUB" },
    
  
    { name: "Ozon Premium",             color: "#0057FF", icon: "📦", currency: "RUB" },
    { name: "Wildberries",              color: "#9564FF", icon: "🛍️", currency: "RUB" },
    { name: "Яндекс Маркет",            color: "#FFCC00", icon: "🛒", currency: "RUB" },
    { name: "СберМаркет",               color: "#21A038", icon: "🛒", currency: "RUB" },
    { name: "Delivery Club",            color: "#FF5E00", icon: "🍕", currency: "RUB" },
    { name: "Яндекс Еда",               color: "#FFCC00", icon: "🍔", currency: "RUB" },
    { name: "Купер (Перекрёсток)",      color: "#00A550", icon: "🛒", currency: "RUB" },
    { name: "Самокат",                  color: "#FF4B4B", icon: "🛵", currency: "RUB" },
    

    { name: "Бусти (Boosty)",           color: "#FF6B00", icon: "🚀", currency: "RUB" },
    { name: "VK Play",                  color: "#5181B8", icon: "🎮", currency: "RUB" },
    { name: "Lava.top",                 color: "#FF3366", icon: "🔥", currency: "RUB" },
    { name: "DonationAlerts",           color: "#FF6600", icon: "🎁", currency: "RUB" },
    
 
    { name: "ЛитРес",                   color: "#FF6600", icon: "📚", currency: "RUB" },
    { name: "Букмейт",                  color: "#FF9900", icon: "📖", currency: "RUB" },
    { name: "Строки (МТС)",             color: "#E30613", icon: "📚", currency: "RUB" },
    { name: "Skillbox",                 color: "#00A1E8", icon: "💻", currency: "RUB" },
    { name: "Нетология",                color: "#FF5C39", icon: "🎓", currency: "RUB" },
    { name: "Яндекс Практикум",         color: "#FFCC00", icon: "💻", currency: "RUB" },
    

    { name: "ChatGPT Plus",             color: "#10A37F", icon: "🤖", currency: "USD" },
    { name: "YandexGPT",                color: "#FFCC00", icon: "🤖", currency: "RUB" },
    { name: "Кандинский (нейросеть)",   color: "#FF69B4", icon: "🎨", currency: "RUB" },
    { name: "Shedevrum",                color: "#FF1493", icon: "🎨", currency: "RUB" },
    
    { name: "Яндекс Здоровье",          color: "#FFCC00", icon: "💊", currency: "RUB" },
    { name: "СберЗдоровье",             color: "#21A038", icon: "🏥", currency: "RUB" },
    { name: "DOC+",                     color: "#00AEEF", icon: "👨‍⚕️", currency: "RUB" },
    

    { name: "Домклик",                  color: "#FF9900", icon: "🏠", currency: "RUB" },
    { name: "Яндекс Недвижимость",      color: "#FFCC00", icon: "🏠", currency: "RUB" },
    
  
    { name: "Netflix",                  color: "#E50914", icon: "🎬", currency: "USD" },
    { name: "YouTube Premium",          color: "#FF0000", icon: "📺", currency: "USD" },
    { name: "Spotify",                  color: "#1DB954", icon: "🎵", currency: "USD" },
    { name: "Apple Music",              color: "#FC3C44", icon: "🎵", currency: "USD" },
    { name: "Discord Nitro",            color: "#5865F2", icon: "💜", currency: "USD" },
    { name: "Telegram Premium",         color: "#26A5E4", icon: "✈️", currency: "USD" },
    { name: "Amazon Prime",             color: "#00A8E1", icon: "📦", currency: "EUR" },
    { name: "Disney+",                  color: "#113CCF", icon: "✨", currency: "EUR" },
    { name: "HBO Max",                  color: "#5822B4", icon: "🎬", currency: "EUR" },
];


popularServices.sort((a, b) => a.name.localeCompare(b.name, 'ru'));


const currencySymbols = {
    "RUB": "₽",
    "USD": "$",
    "EUR": "€",
    "GBP": "£",
    "KZT": "₸",
    "UAH": "₴",
    "BYN": "Br"
};


const exchangeRates = {
    "RUB": 1,
    "USD": 90,
    "EUR": 98,
    "GBP": 115,
    "KZT": 0.20,
    "UAH": 2.4,
    "BYN": 28
};

window.popularServices = popularServices;
window.currencySymbols = currencySymbols;
window.exchangeRates = exchangeRates;